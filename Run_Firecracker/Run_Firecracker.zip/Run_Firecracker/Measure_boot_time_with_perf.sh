#!/bin/bash

sudo perf kvm stat record -a &

sudo ./Start_Firecracker.sh &> out.txt &

sleep 1

sudo ./Run_VM_on_Firecracker.sh &> /dev/null

sleep 2

sudo pkill firecracker

sudo pkill perf 

sleep 1

sudo perf kvm stat report &> data.txt

sudo rm -f perf* &> /dev/null
sudo rm -f out.txt &> /dev/null
sudo rm rootfs.ext4
sudo rm vmlinux.bin